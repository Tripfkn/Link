console.log("inicio da operação");

for(let i = 0; i < 10; i++){
    console.log(i);
}

console.log("fim da operação");